﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Generator;

namespace Project.Core
{
    public class DataBase
    {
        protected static string FileName = "data";
        protected static string FileExtension = ".csv";
        public static string[] RawData { get; set; }
        public static List<int[]> Data { get; set; }
    }
    public class FileWriter: DataBase
    {
        public FileWriter()
        {
            if (!File.Exists(DataBase.FileName + DataBase.FileExtension))
            {
                File.WriteAllText(DataBase.FileName + DataBase.FileExtension, "");
                for (int i = 1; i < 2001; i++)
                {
                    File.AppendAllText(DataBase.FileName + DataBase.FileExtension,ArrayGenerator.ArrayToString(ArrayGenerator.GenerateArray(i, 1000)));
                }
            }
            else
            {
                string[] data = File.ReadAllLines(DataBase.FileName + DataBase.FileExtension);
                if (!(data.Length > 1999))
                {
                    File.Delete(DataBase.FileName + DataBase.FileExtension);
                    StreamWriter writer = new StreamWriter(DataBase.FileName + DataBase.FileExtension, false);
                    for (int i = 1; i < 2001; i++)
                    {
                        File.AppendAllText(DataBase.FileName + DataBase.FileExtension, ArrayGenerator.ArrayToString(ArrayGenerator.GenerateArray(i, 1000)));
                    }
                }
            }
        }
    }
    public class FileReader: DataBase
    {
        public FileReader()
        {
            if (!File.Exists(DataBase.FileName + DataBase.FileExtension)) throw new Exception("There's no such file in dir!");
            else
            {
                DataBase.RawData = File.ReadAllLines(DataBase.FileName + DataBase.FileExtension);
                List <int[]> final = new List < int[]>();
                foreach (string line in DataBase.RawData)
                {
                    string[] raw = line.Split(" ");
                    int[] arr = new int[raw.Length];
                    for (int i = 0; i < raw.Length; i++)
                    {
                        arr[i] = int.Parse(raw[i]);
                    }
                    final.Add(arr);
                }
                DataBase.Data = final;
            }
        }
    }
}

