﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Task_One;

namespace Nikolaev_Lab
{
    class Program
    {
        public static void Main()
        {
            string[] names = Directory.GetFiles(Environment.CurrentDirectory);
            foreach (string name in names)
            {
                List<string> list = new List<string>();
                list = name.Split(".").ToList();
                if (!(list.Contains("data")))
                    if (list.Contains("csv")) MatrixExperiment.FileDeleter.DeleteFile(name);
            }
            Project.Core.FileWriter l = new Project.Core.FileWriter();
            Project.Core.FileReader fileReader = new Project.Core.FileReader();
            Screen.ChooseTask(Screen.AskUser());
        }
        //    public static void GetFunction(int numberFn, int[] numbersArray, int i, int sum, int polynomial, double number, int degree, int pow)
        //    {
        //        switch (numberFn)
        //        {
        //            case 2:
        //                Task2.SummElems(numbersArray, i);
        //                break;
        //            case 4:
        //                Task4.Polynomial(numbersArray, polynomial);
        //                break;
        //            case 6:
        //                Task6.QuickSort(numbersArray);
        //                break;
        //            case 8:
        //                Task8.Pow(number, degree, pow);
        //                break;  
        //        }
        //    }

        //    const int numbers = 2000;
        //    static void Main(string[] args)
        //    {
        //        Random random = new Random(); 
        //        Stopwatch stopwatch =new Stopwatch();
        //        double[] time = new double[numbers];
        //        int[] numbersArray = new int[numbers];
        //        for (int i = 0; i < numbers; i++)
        //        {
        //            numbersArray[i] = random.Next();
        //        }
        //        int sum = 0;
        //        int numberFn = 8;   // Номер функции, которую хотим вызвать
        //        int polynomial = 2; // 1 - Вычисляем путем прямого (наивного) вычисления |
        //                            //                                                   |   Для задания 1.4
        //                            // 2 - Вычисляем методом Горнера                     |

        //        double number = 5;
        //        int degree = 500;
        //        int pow = 4;        // 1 - Возведение в степень (простой алгоритм)                 |
        //                            // 2 - Возведение в степень (рекурсивный алгоритм)             |  Для задания 1.8
        //                            // 3 - Возведение в степень (быстрый алгоритм)                 |
        //                            // 4 - Возведение в степень (классический быстрый алгоритм)    |
        //        for (int i = 0; i < numbers; i++)
        //        {
        //            stopwatch.Start();
        //            GetFunction(numberFn, numbersArray, i, sum, polynomial, number, degree, pow);
        //            stopwatch.Stop();
        //            time[i] = (stopwatch.Elapsed.TotalMilliseconds);
        //        }

        //        WriteTime(time);
        //        Console.WriteLine("Completed");
        //        Console.ReadKey();

        //        static void WriteTime(double[] time)
        //        {
        //            string path = @"C:\Users\Azerty\Desktop\C#\Nikolaev_Lab\Nikolaev_Lab1\Nikolaev_Lab\Nikolaev_Lab\bin\Debug\net6.0\time.csv";
        //            using (StreamWriter sw = new StreamWriter(path))
        //            {
        //                for (int i = 0; i < numbers; i++)
        //                {
        //                    sw.WriteLine(time[i]);
        //                }
        //            }
        //        }     
        //    }
        //}
    }
}
