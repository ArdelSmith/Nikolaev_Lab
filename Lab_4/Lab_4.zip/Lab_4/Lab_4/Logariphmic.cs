﻿
namespace Lab_4
{
    public static class Logariphmic
    {
        static List<string> log = new List<string>();
        public static void SortWithQuickSort(int[] a)
        {
            QuickSort(a);
        }
        //метод для обмена элементов массива
        static void Swap(ref int x, ref int y)
        {
            var t = x;
            x = y;
            y = t;
        }

        //метод возвращающий индекс опорного элемента
        static int Partition(int[] array, int minIndex, int maxIndex)
        {
            var pivot = minIndex - 1;
            for (var i = minIndex; i < maxIndex; i++)
            {
                if (array[i] < array[maxIndex])
                {
                    log.Add($"Элемент {array[i]} с индексом {i} больше, чем элемент {array[maxIndex]} с индексом {maxIndex}, меняем их местами");
                    pivot++;
                    Swap(ref array[pivot], ref array[i]);
                    log.Add("Массив принял вид:");
                    log.Add(array.ArrayToString());
                }
            }
            pivot++;
            log.Add($"Меняем местами элемент {array[pivot]} с индексом {pivot} и элемент {array[maxIndex]} с индексом {maxIndex}");
            log.Add("Массив принял вид:");
            Swap(ref array[pivot], ref array[maxIndex]);
            log.Add(array.ArrayToString());
            return pivot;
        }

        //быстрая сортировка
        static int[] QuickSort(int[] array, int minIndex, int maxIndex)
        {
            if (minIndex >= maxIndex)
            {
                return array;
            }

            var pivotIndex = Partition(array, minIndex, maxIndex);
            QuickSort(array, minIndex, pivotIndex - 1);
            QuickSort(array, pivotIndex + 1, maxIndex);
            log.Add("Сортировка завершена:");
            log.Add(array.ArrayToString());
            FileWriter.WriteFile(log.ToArray(), "Quick.txt");
            return array;
        }

        static int[] QuickSort(int[] array)
        {
            return QuickSort(array, 0, array.Length - 1);
        }

    }
}